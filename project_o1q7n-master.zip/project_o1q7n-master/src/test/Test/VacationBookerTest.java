package Test;

import model.ActivitiesList;
import model.Flight;
import model.Hotel;
import model.VacationBooker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ui.Activities;

import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

class VacationBookerTest {

    @Test
    void testHotelToString() {
        Hotel testHotel = new Hotel("Sheraton Istanbul City Centre", "4.5", 164);
        testHotel.setName("Sheraton Istanbul City Centre");
        testHotel.setStars("4.5");
        testHotel.setPrice(164);
        assertTrue(testHotel.toString().contains("Sheraton Istanbul City Centre $164/night 4.5 stars"));
        assertTrue(testHotel.getName().contains("Sheraton Istanbul City Centre"));
        assertTrue(testHotel.getStars().contains("4.5"));
        assertEquals(testHotel.getPrice(), 164);
    }

    @Test
    void testFlightToString() {
        Flight testFlight = new Flight("AirFrance", 1228, 20, 35, 2);
        testFlight.getCost(2);
        assertTrue(testFlight.getFlight().contains("AirFrance"));
        assertEquals(testFlight.getCost(2), 2456);
        assertTrue(testFlight.toString().contains("AirFrance $1228, 20hrs 35min, 2 stops"));
        Flight testFlight2 = new Flight("null", 0, 0, 0, 0);
        assertTrue(testFlight2.toString().contains("null"));
    }

    @Test
    void testFlightCost() {
        VacationBooker dest1 = new VacationBooker();
        int totalFlightCost = 200;
        dest1.setTotalFlightCost(totalFlightCost);
        int people = 2;
        dest1.setPeople(people);
        assertEquals(2, dest1.getPeople());
        assertEquals(200, dest1.getTotalFlightCost());

    }

    @Test
    void testGetName() {
        VacationBooker dest1 = new VacationBooker();
        String name = "maliha";
        dest1.setName(name);
        assertEquals("maliha", dest1.getName());
    }

    @Test
    void testGetDestination() {
        VacationBooker dest1 = new VacationBooker();
        int destination = 1;
        dest1.setDestination(destination);
        assertEquals(destination ,dest1.getDestination());
    }

    @Test
    void testGetCity() {
        VacationBooker dest1 = new VacationBooker();
        String city = "Athens";
        dest1.setCity(city);
        assertEquals("Athens", dest1.getCity());
    }

    @Test
    void testDays(){
        VacationBooker dest1 = new VacationBooker();
        int days = 2;
        dest1.setDays(days);
        assertEquals(2, dest1.getDays());
    }

    @Test
    void testGetRooms(){
        VacationBooker dest1 = new VacationBooker();
        int rooms = 3;
        dest1.setRoomsBooked(rooms);
        assertEquals(3, dest1.getRoomsBooked());
    }

    @Test
    void testYesOrNo(){
        VacationBooker dest1 = new VacationBooker();
        String yesOrNo = "yes";
        dest1.setYesOrNo(yesOrNo);
        assertEquals("yes", dest1.getYesOrNo());
    }

    @Test
    void testGetBags(){
        VacationBooker dest1 = new VacationBooker();
        int bags = 2;
        dest1.setNumberOfBags(bags);
        assertEquals(2, dest1.getNumberOfBags());
    }

    @Test
    void testBagPrice(){
        VacationBooker dest1 = new VacationBooker();
        int bagPrice = 50;
        dest1.setBagPrice(bagPrice);
        assertEquals(50, dest1.getBagPrice());
    }

    @Test
    void testHotelPrice() {
        VacationBooker dest1 = new VacationBooker();
        int hotelPrice = 100;
        dest1.setTotalHotelPrice(hotelPrice);
        assertEquals(100, dest1.getTotalHotelPrice());
        dest1.setHotelPrice(hotelPrice);
        assertEquals(100, dest1.getHotelPrice());
    }

    @Test
    void testGetHotelObj() {
        VacationBooker dest1 = new VacationBooker();
        Hotel hotelObj = null;
        dest1.setHotelObj(hotelObj);
        assertEquals(hotelObj, dest1.getHotelObj());
    }

    @Test
    void testGetFlightObj() {
        VacationBooker dest1 = new VacationBooker();
        Flight flightObj = null;
        dest1.setFlightObj(flightObj);
        assertEquals(flightObj, dest1.getFlightObj());
    }

    @Test
    void testCreateActivity() {
        Activities activities = new Activities();
        String activity = "surfing";

        ActivitiesList act = new ActivitiesList();
        //act.activitiesList(activity);
    }

    @Test
    void testWriterEmptyVacationBooker() {

    }

    @Test
    void testWriterVacationBooker() {

    }

}



