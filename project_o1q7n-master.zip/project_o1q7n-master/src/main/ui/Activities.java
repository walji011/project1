package ui;

import model.ActivitiesList;
import org.json.JSONArray;
import org.json.JSONObject;
import persistence.Writable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;


//A class which creates different activities and adds it to a list in the ActivitiesList class
public class Activities implements Writable {
    private String activity;

    public void activities(String activity) {
        this.activity = activity;
    }

    //REQUIRES: input of yes
    //MODIFIES: alist
    //EFFECTS: prompts user to add as many activities as they would like and
    //adds it to a list in the ActivitiesList class
    public void getActivity() throws IOException {
        InputStreamReader reader = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(reader);
        System.out.println("Would you like to plan out what activities you may do on your trip?");
        String yesNo = br.readLine();
        while (yesNo.equals("yes")) {
            System.out.println("Please enter in an activity");
            activity = br.readLine();
            ActivitiesList.getList().add(activity);
            System.out.println("Would you like to add another?");
            yesNo = br.readLine();
        }
        ActivitiesList act = new ActivitiesList();
        act.activitiesList(String.valueOf(activity));
    }

    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("activity", activity);
        return json;
    }

}

