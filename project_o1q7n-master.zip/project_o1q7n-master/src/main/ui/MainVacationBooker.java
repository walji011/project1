package ui;

import model.ActivitiesList;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

//Constructs new Processor object to begin program
public class MainVacationBooker {

    //Creates new Processor class obj and calls process method to begin functions
    public static void main(String[] args) throws IOException {
        Processor dp = new Processor();
        dp.process();
    }
}
