package ui;

import model.ActivitiesList;
import model.Flight;
import model.Hotel;
import model.VacationBooker;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

import persistence.JsonReader;
import persistence.JsonWriter;

//Class contains most functions which receive input and produce output
public class Processor {
    private static final String JSON_STORE = "./data/vacationBooker.json";
    private JsonWriter jsonWriter;
    private JsonReader jsonReader;

    public  Processor() {
        jsonWriter = new JsonWriter(JSON_STORE);
    }


    public void saveToFile(VacationBooker dest) {
        try {
            jsonWriter.open();
            jsonWriter.write(dest);
            jsonWriter.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    //MODIFIES: this
    //EFFECTS: Creates new obj VacationBooker and calls different functions in correct order, then confirms booking if
    //user inputs yes otherwise ends program
    public void process() throws IOException {
        jsonReader = new JsonReader(JSON_STORE);
        VacationBooker dest = jsonReader.read();

        Scanner in = new Scanner(System.in);
        intro();
        getName(dest, in);
        getNumPeople(dest, in);
        getDestination(dest, in);
        execute(dest, in);


        System.out.println("Would you like to confirm the booking? If not you can make another plan "
                + "\nEnter yes or no");
        if (!Objects.equals(in.nextLine(), "yes")) {

            System.exit(1);
        }
        displayDetails(dest, in);
        System.out.println("Congratulations " + dest.getName() + ", your booking is confirmed!");
        getRestaurant(dest, in);
        Activities activities2 = new Activities();
        activities2.getActivity();

        saveToFile(dest);
    }

    //EFFECTS: prints out a statement and introduces app
    private void intro() {
        System.out.println("Hello! Welcome to Canoe, where you can plan and book a vacation of a lifetime!");
        System.out.println("Please enter the name of the person this booking will be under");
    }

    //MODIFIES: dest, in
    //EFFECTS: gets number of travellers from user and prints it
    public static void getNumPeople(VacationBooker dest, Scanner in) {
        System.out.println("How many people are in your party?");
        dest.setPeople(Integer.parseInt(in.nextLine()));
        System.out.println("Okay, " + dest.getPeople() + " people");
    }

    //MODIFIES: dest, in
    //EFFECTS: gets name from user and prints a statement including the input
    public static void getName(VacationBooker dest, Scanner in) {
        dest.setName(in.nextLine());
        System.out.println("Okay " + dest.getName() + " lets get started!");
    }

    //REQUIRES: user input
    //MODIFIES: dest, in
    //EFFECTS: returns destination unless input isn't within option range then returns "invalid input"
    public static void getDestination(VacationBooker dest, Scanner in) {
        System.out.println("Please choose a destination, for Athens press 1, "
                + "for Istanbul press 2, for Dubai press 3");
        int option1 = Integer.parseInt(in.nextLine());
        while (option1 < 1 || option1 >= 4) {
            System.out.println("Invalid!");
            option1 = Integer.parseInt(in.nextLine());
        }
        dest.setDestination(option1);
    }

    //REQUIRES: positive value
    //MODIFIES: dest, in
    //EFFECTS: Asks user how many bags they would like to bring on their vacation and returns the total cost
    //based on set bag price
    public static void setBagPrice(VacationBooker dest, Scanner in) {
        System.out.println("Enter the number of bags you plan on taking \n *** Each bag costs $50 ***");
        dest.setNumberOfBags(Integer.parseInt(in.nextLine()));
        dest.setBagPrice(dest.getNumberOfBags() * 50);
        System.out.println("$" + dest.getBagPrice() + " is the total price of your bags");
    }

    //REQUIRES:  1 <= input <= 3
    //MODIFIES: dest, in, flights
    //EFFECTS: Prompts user to select flight, returns selected flight and the total cost of flights (getCost)
    public static void getFlight(VacationBooker dest, Scanner in, Flight[] flights) {
        System.out.println(dest.getCity() + ", great choice!");
        System.out.println("Let's book the flights first, please select the option by entering a number \n"
                + "*** All flights round trip *** \n");
        for (int i = 0; i < flights.length; i++) {
            System.out.println((i + 1) + ". " + flights[i]);
        }
        int option1 = Integer.parseInt(in.nextLine());
        while (option1 < 1 || option1 > flights.length) {
            System.out.println("Invaid!");
            option1 = Integer.parseInt(in.nextLine());
        }
        dest.setFlightObj(flights[option1 - 1]);
        System.out.println(dest.getFlightObj());
        System.out.println("$" + dest.getCost() + " is the total cost of your flights");
    }

    //REQUIRES:  1 <= input <= 3
    //MODIFIES: details, dest, in, hotels
    //EFFECTS: Based on user input prints the details of the kind of hotel they can book
    //If user inputs a number not 1-3 from options presented returns invalid input
    public static void getHotel(String details, VacationBooker dest, Scanner in, Hotel[] hotels) {
        System.out.println(details);
        int option1 = Integer.parseInt(in.nextLine());
        while (option1 < 1 || option1 > 3) {
            System.out.println("Invalid input!");
            option1 = Integer.parseInt(in.nextLine());
        }
        dest.setHotelObj(hotels[option1 - 1]);
        System.out.println(dest.getHotelObj());
    }

    //REQUIRES: input an integer
    //MODIFIES: dest, in
    //EFFECTS: Asks user how many nights they are staying and how many rooms they would like to book
    //returns total board cost based on user input
    public static void setNightsAndRooms(VacationBooker dest, Scanner in) {
        System.out.println("How many nights do you plan on spending?");
        int numberOfDays = Integer.parseInt(in.nextLine());
        System.out.println("How many rooms would you like to book?");
        int rooms = Integer.parseInt(in.nextLine());
        dest.setTotalHotelPrice(numberOfDays * dest.getHotelObj().getPrice() * rooms);
        dest.setDays(numberOfDays);
        dest.setRoomsBooked(rooms);
        System.out.println("The total cost of your board is: $" + dest.getTotalHotelPrice());
    }

    //REQUIRES: input to be 0 < input < 4 from getDestination and getHotel
    //EFFECTS: returns user selection details (flights and hotels)
    public static void execute(VacationBooker dest, Scanner in) {
        Flight[] f = null;
        Hotel[] h = null;
        String[] cities = {"Athens", "Istanbul", "Dubai"};
        Flight luft = new Flight("Lufthansa", 1204, 13, 50, 1);
        Flight air = new Flight("AirFrance", 1228, 20, 35, 2);
        Flight ba = new Flight("British Airways", 1212, 14, 45, 1);
        Hotel elia = new Hotel("Elia Ermou Athens Hotel", "4.5", 190);
        Hotel bretagne = new Hotel("Hotel Grande Bretagne", "4.5", 755);
        Hotel electra = new Hotel("Electra Metropolis Athens", "4.5", 333);

        Flight t = new Flight("Turkish Airlines", 1620, 17, 25, 1);
        Flight l = new Flight("Lufthansa", 2019, 16, 25, 1);
        Hotel s = new Hotel("Swissotel The Bosphorus", "5", 450);
        Hotel sh = new Hotel("Sheraton Istanbul City Centre", "4.5", 164);
        Hotel su = new Hotel("Sura Hagia Sophia Hotel", "4.5", 242);

        Flight luft1 = new Flight("Lufthansa", 1399, 21, 50, 1);
        Flight q = new Flight("Qatar Airways", 1787, 28, 0, 2);
        Flight ba1 = new Flight("British Airways", 1478, 38, 30, 1);
        Hotel h1 = new Hotel("Waldorf Astoria", "4.7", 407);
        Hotel h2 = new Hotel("Atlantis The Palm", "4.5", 826);
        Hotel h3 = new Hotel("St. Regis Downtown Dubai", "5", 294);
        String details = "";
        decideDetails(dest, in, f, h, cities, luft, air, ba, elia,
                bretagne, electra, t, l, s, sh, su, luft1, q, ba1, h1, h2, h3, details);
    }

    //REQUIRES: 1 <= input <= 3
    //MODIFIES: this dest, in, f, h, cities, luft, air, ba, elia, bretagne, electra, t, l, s, sh
    // su, luft1, q, ba1, h1, h2, h3, details
    //EFFECTS: gets details on flight, hotel
    public static void decideDetails(VacationBooker dest, Scanner in, Flight[] f, Hotel[] h,
                                 String[] cities, Flight luft, Flight air, Flight ba, Hotel elia,
                                 Hotel bretagne, Hotel electra, Flight t, Flight l, Hotel s, Hotel sh,
                                 Hotel su, Flight luft1, Flight q, Flight ba1, Hotel h1, Hotel h2,
                                 Hotel h3, String details) {

        if (dest.getDestination() == 1) {
            f = new Flight[]{luft, air, ba};
            details = ("Let's move on to hotel booking \n What kind of hotel are you looking for? \n "
                    + "1: Affordable with good ratings 2: Luxury hotel " + "3: midrange pricing");
            h = new Hotel[]{elia, bretagne, electra};

        } else if (dest.getDestination() == 2) {
            f = new Flight[]{t, l};
            details = ("Let's move on to hotel booking \n What kind of hotel are you looking for? \n "
                    + "1: Luxury 2: Affordable "
                    + "3: Historical atmosphere");
            h = new Hotel[]{s, sh, su};
        } else if (dest.getDestination() == 3) {
            f = new Flight[]{luft1, q, ba1};
            details = ("Let's move on to hotel booking \n What kind of hotel are you looking for? \n "
                    + "1: midrange pricing with sea views 2: Luxury hotel with sea views"
                    + " 3: downtown views affordable pricing");
            h = new Hotel[]{h1, h2, h3};
        }
        dest.setCity(cities[dest.getDestination() - 1]);
        getFlight(dest, in, f);
        setBagPrice(dest, in);
        getHotel(details, dest, in, h);
        setNightsAndRooms(dest, in);
    }

    //MODIFIES: dest, in
    //EFFECTS: Displays the details gathered from the user
    public void displayDetails(VacationBooker dest, Scanner in) {
        int tripTotal = (dest.getTotalHotelPrice() + dest.getTotalFlightCost() + dest.getBagPrice());
        System.out.println("Okay " + dest.getName() + ", the total cost of your trip is $" + tripTotal);
        System.out.println("Let's go over all the details:\n"
                + " Name: " + dest.getName() + "\n" + " City: " + dest.getCity() + "\n Flight(s): "
                + dest.getPeople() + " tickets, " + dest.getFlightObj() + ", $" + dest.getTotalFlightCost()
                + "\n Bag(s) cost: $" + dest.getBagPrice() + "\n Travellers: " + dest.getPeople()
                + "\n Days: " + dest.getDays() + "\n Hotel: " + dest.getHotelObj()
                + ", $" + dest.getTotalHotelPrice() + ", rooms - "
                + dest.getRoomsBooked() + "\n Total: $" + tripTotal);
    }

    //REQUIRES: input of yes
    //MODIFIES: restaurant, dest, in
    //EFFECTS: returns user inputs of restaurant names and calculates avg price they may pay at each
    private void getRestaurant(VacationBooker dest, Scanner in) {
        ArrayList<String> restaurant = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Would you like to add in restaurants you may want to visit on your trip?");
        String yesOrNo = in.nextLine();
        if (Objects.equals(yesOrNo, "yes")) {
            System.out.println("Okay, please enter the name of the restaurant");
            restaurant.add(scanner.next());
            System.out.println("would you like to add another?");
            yesOrNo = in.nextLine();
            while (Objects.equals(yesOrNo, "yes")) {
                System.out.println("Okay, please enter the name of the restaurant");
                restaurant.add(scanner.next());
                System.out.println("would you like to add another?");
                yesOrNo = in.nextLine();
            }
            int numberOfRestaurants = restaurant.size();
            int totalRestaurant = numberOfRestaurants * 20 * dest.getPeople();
            System.out.println("These are the restaurants you plan on visiting: \n" + restaurant
                    + "\nKeep in mind that the estimated total cost spent at each restaurant"
                    + " is the avg price of an entree * the number of people in your party\n"
                    + "Estimated cost per restaurant: $" + 20 * dest.getPeople()
                    + "\nYour estimated total is: $" + totalRestaurant);
        }

    }
}
