package persistence;

import model.VacationBooker;
import model.Flight;
import model.ActivitiesList;
import org.json.JSONArray;
import org.json.JSONObject;
import ui.Activities;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class JsonReader {
    private String source;

    public JsonReader(String source) {
        this.source = source;
    }

    // MODIFIES:
    // EFFECTS:
    public VacationBooker read() throws IOException {
        String jsonData = readFile(source);
        JSONObject jsonObject = new JSONObject(jsonData);
        return addVacationBooker(jsonObject);
    }

    // MODIFIES:
    // EFFECTS:
    private String readFile(String source) throws IOException {
        StringBuilder contentBuilder = new StringBuilder();

        try (Stream<String> stream = Files.lines(Paths.get(source), StandardCharsets.UTF_8)) {
            stream.forEach(s -> contentBuilder.append(s));
        }

        return contentBuilder.toString();
    }


    // MODIFIES:
    // EFFECTS:
    private VacationBooker addVacationBooker(VacationBooker dest, JSONObject jsonObject) {
        String name = jsonObject.getString("name");
        int totalFlightCost = jsonObject.getInt("totalFlightCost");
        int totalHotelPrice = jsonObject.getInt("totalHotelPrice");
        int hotelPrice = jsonObject.getInt("hotelPrice");
        int bagPrice = jsonObject.getInt("bagPrice");
        String city = jsonObject.getString("city");
        int days = jsonObject.getInt("days");
        int roomsBooked = jsonObject.getInt("roomsBooked");
        //String yesOrNo = jsonObject.getString("yesOrNo");
        int destination = jsonObject.getInt("destination");
        int people = jsonObject.getInt("people");
        int numberOfBags = jsonObject.getInt("numberOfBags");

        return dest;
    }

    // MODIFIES:
    // EFFECTS:
    private void addActivitiesList(Activities activities, JSONObject jsonObject) {
        JSONArray jsonArray = jsonObject.getJSONArray("alist");
        for (Object json : jsonArray) {
            JSONObject nextActivity = (JSONObject) json;

        }
    }

    // MODIFIES:
    // EFFECTS:
    /*private void addHotel(Hotel hotel1, JSONObject jsonObject) {
        String name = jsonObject.getString("name");
        String stars = jsonObject.getString("stars");
        int price = jsonObject.getInt("price");
        hotel1 = new Hotel(name, stars, price);
        hotel1.toString(hotel1);
    }*/

    // MODIFIES:
    // EFFECTS:
    /*private Hotel parseHotel (JSONObject jsonObject) {
        String name = jsonObject.getString("name");
        addHotel(hotel1, jsonObject);
        hotel1 = new Hotel();
        return hotel1;
    }*/

    // MODIFIES:
    // EFFECTS:
    private Flight addFlight(Flight flight1, JSONObject jsonObject) {
        String flight = jsonObject.getString("flight");
        String stars = jsonObject.getString("price");
        int price = jsonObject.getInt("price");
        int hours = jsonObject.getInt("hours");
        int minutes = jsonObject.getInt("minutes");
        int stops = jsonObject.getInt("stops");
        flight1 = new Flight(flight, price, hours, minutes, stops);
        flight1.toString();
        addFlight(flight1, jsonObject);
        return flight1;
    }

}
