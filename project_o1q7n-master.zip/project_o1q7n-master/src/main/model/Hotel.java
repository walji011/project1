package model;

import org.json.JSONObject;
import persistence.Writable;

//Instantiates all variables relating to hotel booking
public class Hotel implements Writable {
    private String name;
    private String stars;
    private int price;

    public Hotel(String name, String stars, int price) {
        this.name = name;
        this.stars = stars;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStars() {
        return stars;
    }

    public void setStars(String stars) {
        this.stars = stars;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    //returns all hotel details in string format
    public String toString() {
        return this.getName() + " $" + this.getPrice() + "/night " + this.getStars() + " stars";
    }

    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("name", name);
        json.put("stars", stars);
        json.put("price", price);
        return json;
    }
}
