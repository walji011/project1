package model;

import org.json.JSONArray;
import org.json.JSONObject;
import persistence.Writable;
import ui.Activities;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class ActivitiesList implements Writable {
    private static ArrayList<Activities> alist = new ArrayList();
    InputStreamReader reader = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(reader);

    public static ArrayList getList() {
        return alist;
    }

    //REQUIRES: input from Activities class
    //MODIFIES: activity, alist
    //EFFECTS: prints out list of activities, alist
    public void activitiesList(String activity) throws IOException {
        System.out.println("Okay great! Would you like to check out your list of activities?");
        String yesNo = br.readLine();
        if (yesNo.equals("yes")) {
            System.out.println(alist);
        }
    }


    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("alist", activitiesToJson());
        return json;
    }

    private JSONArray activitiesToJson() {
        JSONArray jsonArray = new JSONArray();

        for (Activities activities : alist) {
            jsonArray.put(activities.toJson());
        }
        return jsonArray;
    }
}


