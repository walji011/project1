package model;

import org.json.JSONObject;
import persistence.Writable;

//declares and sets all variables necessary for the program to run
public class VacationBooker implements Writable {

    private String name;
    private int totalFlightCost;
    private int totalHotelPrice;
    private int hotelPrice;
    private int bagPrice;
    private String city;
    private int days;
    private int roomsBooked;
    private String yesOrNo;
    private int destination;
    private int people;
    private int numberOfBags;
    private Flight flightObj;
    private Hotel hotelObj;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Hotel getHotelObj() {
        return hotelObj;
    }

    public void setHotelObj(Hotel hotelObj) {
        this.hotelObj = hotelObj;
    }


    public int getNumberOfBags() {
        return numberOfBags;
    }

    public void setNumberOfBags(int numberOfBags) {
        this.numberOfBags = numberOfBags;
    }

    public Flight getFlightObj() {
        return flightObj;
    }

    public void setFlightObj(Flight flightObj) {
        this.flightObj = flightObj;
    }


    public int getPeople() {
        return people;
    }

    public void setPeople(int people) {
        this.people = people;
    }

    public int getDestination() {
        return destination;
    }

    public void setDestination(int destination) {
        this.destination = destination;
    }

    public int getTotalHotelPrice() {
        return totalHotelPrice;
    }

    public void setTotalHotelPrice(int totalHotelPrice) {
        this.totalHotelPrice = totalHotelPrice;
    }

    public int getTotalFlightCost() {
        return totalFlightCost;
    }

    public void setTotalFlightCost(int totalFlightCost) {
        this.totalFlightCost = totalFlightCost;
    }

    public int getHotelPrice() {
        return hotelPrice;
    }

    public void setHotelPrice(int hotelPrice) {
        this.hotelPrice = hotelPrice;
    }

    public int getBagPrice() {
        return bagPrice;
    }

    public void setBagPrice(int bagPrice) {
        this.bagPrice = bagPrice;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public int getRoomsBooked() {
        return roomsBooked;
    }

    public void setRoomsBooked(int roomsBooked) {
        this.roomsBooked = roomsBooked;
    }

    public String getYesOrNo() {
        return yesOrNo;
    }

    public void setYesOrNo(String yesOrNo) {
        this.yesOrNo = yesOrNo;
    }

    public int getCost() {
        totalFlightCost = this.getFlightObj().getCost(people);
        return totalFlightCost;
    }

    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("name", name);
        json.put("totalFlightCost", totalFlightCost);
        json.put("totalHotelPrice", totalHotelPrice);
        json.put("hotelPrice", hotelPrice);
        json.put("bagPrice", bagPrice);
        json.put("city", city);
        json.put("days", days);
        json.put("roomsBooked", roomsBooked);
        json.put("yesOrNo", yesOrNo);
        json.put("destination", destination);
        json.put("people", people);
        json.put("numberOfBags", numberOfBags);
        json.put("flightObj", flightObj);
        json.put("hotelObj", hotelObj);
        return json;
    }
}

