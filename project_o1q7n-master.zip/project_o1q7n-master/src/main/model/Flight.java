package model;

import org.json.JSONObject;
import persistence.Writable;

//Instantiates all variables relating to flight booking
public class Flight implements Writable {

    private final String flight;
    private final int price;
    private final int hours;
    private final int minutes;
    private final int stops;

    public Flight(String flight, int price, int hours, int minutes, int stops) {
        this.flight = flight;
        this.price = price;
        this.hours = hours;
        this.minutes = minutes;
        this.stops = stops;
    }

    public int getCost(int people) {
        return this.price * people;
    }

    @Override
    //returns flight details in string format
    public String toString() {
        if (flight != null) {
            return flight + " $" + price + ", " + hours + "hrs " + minutes + "min, " + stops + " stops";
        }
        return "null";
    }

    public String getFlight() {
        return flight;
    }

    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("flight", flight);
        json.put("price", price);
        json.put("hours", hours);
        json.put("minutes", minutes);
        return json;
    }
}
