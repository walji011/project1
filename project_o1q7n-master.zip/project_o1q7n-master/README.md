# My Personal Project - Canoe: A Travel Planning app

### *Canoe is a travel related service that helps you plan out as well as book trips* 

#### This application will prompt a user to give their basic information, then give them different options on locations they can book for vacation. Under each location there are different Airlines and hotels which fits their criteria. Bag costs, number of travellers, rooms and number of days spent are all factored into the total cost. The user can also plan out where they want to eat. If they aren't satisfied with their plan, they can restart and confirm a booking they prefer. Anyone interested in planning a vacation but isn't sure what their plan is yet will find this application useful. I enjoy travelling, and I am going to two of the different locations listed in the summer which inspired this application.
**User Stories**:
- As a user I want to select a vacation spot based off of suggestions given to me
- As a user I want to be able to book a basic travel plan (flight and hotel details)
- As a user I want to pick out which hotel I stay at based off affordability 
- As a user I want to add as many restaurants as I want to my plan and factor it into my total trip cost
- As a user ّI want to be able to add several activities to a list (X to Y)
- As a user I would like to save all my data and come back to it
- As a user I would like to pick up where I left off in the booking process
  